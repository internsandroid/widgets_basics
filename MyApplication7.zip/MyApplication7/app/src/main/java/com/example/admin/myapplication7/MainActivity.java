package com.example.admin.myapplication7;

import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.LayerDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.animation.AnimationUtils;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
    TextView phone,t1,t2,t3,t4;
    ToggleButton tToggle;
    CheckBox checkBox;
    RadioButton male,female;
    RadioGroup radioGroup;
    RadioButton radioButton;
    SeekBar seekBar;
    Switch aSwitch;
    ImageView imageView;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        t1=(TextView) findViewById(R.id.textView);
        t2=(TextView) findViewById(R.id.textView2);
        t3=(TextView) findViewById(R.id.textView3);
        t4=(TextView) findViewById(R.id.textView4);

        checkBox=(CheckBox) findViewById(R.id.checkBox);
        male=(RadioButton) findViewById(R.id.radioMale);
        female=(RadioButton) findViewById(R.id.radioFemale);
        seekBar=(SeekBar) findViewById(R.id.seekBar);
        aSwitch=(Switch) findViewById(R.id.switch1);

        tToggle=(ToggleButton) findViewById(R.id.toggle);

        radioGroup=(RadioGroup) findViewById(R.id.radio);



        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                int selectedId = radioGroup.getCheckedRadioButtonId();


                radioButton= (RadioButton) findViewById(selectedId);


                String a= (String) radioButton.getText();

                t3.setText(a);
            }


        });

        tToggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b)
                {
                    RelativeLayout currentLayout = (RelativeLayout) findViewById(R.id.relative);
                    currentLayout.setBackground( getResources().getDrawable(R.drawable.background_images));


                }
                else
                {
                    RelativeLayout currentLayout = (RelativeLayout) findViewById(R.id.relative);
                    currentLayout.setBackground( getResources().getDrawable(R.drawable.cd));



                }

            }

        });



        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean a) {
                if(a)
                {
                    t2.setText("Check Box selected");

                }
                else

                {
                    t2.setText("Check Box Not selected");

                }
            }

        });

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                int p=0;

        @Override
         public void onStopTrackingTouch(SeekBar seekBar) {
         if (p<30){
              p = 30;
              seekBar.setProgress(p);
          }
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {

        }

       @Override
      public void onProgressChanged(SeekBar seekBar, int progress,boolean fromUser) {
        p=progress;
       t4.setTextSize(p);
        }
        });

        aSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
       @Override
       public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
           if (b) {
               ImageView animationTarget = (ImageView) findViewById(R.id.imageView);


           }
       }
        });

    }

}

