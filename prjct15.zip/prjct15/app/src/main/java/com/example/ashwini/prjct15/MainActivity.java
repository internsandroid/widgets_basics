package com.example.ashwini.prjct15;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.TextureView;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
    ToggleButton toggle;
    TextView textView1, textView2, textView3, textView4;
    ImageView imageView;
    Switch switch1;
    SeekBar seekbar;
    RadioGroup radioGroup;
    RelativeLayout relativeLayout;
    RadioButton radiobutton1, radiobutton2;
    CheckBox checkbox;
    Animation anim;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toggle = (ToggleButton) findViewById(R.id.toggleButton);
        textView1 = (TextView) findViewById(R.id.textView);
        textView2 = (TextView) findViewById(R.id.textView2);
        textView3 = (TextView) findViewById(R.id.textView3);
        textView4 = (TextView) findViewById(R.id.textView4);
        imageView  = (ImageView) findViewById(R.id.imageView);
        switch1 = (Switch) findViewById(R.id.switch1);
        seekbar = (SeekBar) findViewById(R.id.seekBar);
        relativeLayout = (RelativeLayout) findViewById(R.id.relative);
        radioGroup = (RadioGroup) findViewById(R.id.radiogroup);
        radiobutton1 = (RadioButton) findViewById(R.id.radioButton);
        radiobutton2 = (RadioButton) findViewById(R.id.radioButton2);
        checkbox = (CheckBox) findViewById(R.id.checkBox);
        toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked)
                    // buttonView.setBackgroundColor(Color.GREEN);
                    relativeLayout.setBackgroundResource(R.drawable.ic_launcher_background);
                else
                    relativeLayout.setBackgroundResource(R.drawable.ic_launcher_foreground);
            }
        });
        checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (checkbox.isChecked()) {
                    textView2.setText("checkbox selected");

                }
            }
        });
        radiobutton1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (radiobutton1.getId() == R.id.radioButton) {
                    textView3.setText("male");
                }
            }


        });
        radiobutton2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (radiobutton2.getId() == R.id.radioButton2) {
                    textView3.setText("female");
                }
            }
        });
        seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                textView4.setTextSize(Float.valueOf(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                {
                    ImageView animationTarget = (ImageView) findViewById(R.id.imageView);
                    anim = AnimationUtils.loadAnimation(MainActivity.this, R.anim.rotate1);
                    animationTarget.startAnimation(anim);
                }
                else
                {

                }
            }
        });
    }
}


